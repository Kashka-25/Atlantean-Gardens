# 🌿 ATLANTEAN GARDENS WEBSITE - SETUP GUIDE 🌊

## What You Have

A complete, beautiful website for Atlantean Gardens with:
- ✅ Homepage with hero section
- ✅ Public Botanical Shop page
- ✅ Password-protected Members Portal with strain menu
- ✅ About page telling your story
- ✅ Mobile-responsive design
- ✅ All your brand images integrated
- ✅ Soft, dreamy Atlantean aesthetic

---

## 📁 File Structure

```
atlantean-gardens/
├── index.html          (Homepage)
├── members.html        (Password-protected portal)
├── shop.html          (Public botanical shop)
├── about.html         (Your story & philosophy)
├── styles.css         (Main styles)
├── members.css        (Members portal styles)
├── script.js          (Navigation & interactions)
├── members.js         (Password protection)
├── images/            (All your images)
│   ├── tea-ceremony.png
│   ├── chocolate-diesel.png
│   ├── mango-kush.png
│   ├── thin-mints.png
│   ├── ice-cream.png
│   ├── runtz-layer-cake.png
│   ├── pricing-menu.png
│   ├── flower-package.png
│   ├── atlantis-scene.png
│   ├── zoo-scene.png
│   └── logo-white.png
└── README.md          (This file!)
```

---

## 🚀 HOW TO GET YOUR SITE LIVE (Step-by-Step)

### STEP 1: Download VS Code (If you haven't already)
1. Go to: https://code.visualstudio.com/
2. Download and install for your computer
3. Open VS Code

### STEP 2: Get Your Files from Claude
All your files are currently in `/home/claude/atlantean-gardens/`

I'll create a downloadable ZIP for you in the next step!

### STEP 3: Set Up GitHub
1. Go to: https://github.com
2. Sign in (or create account)
3. Click the **+** button (top right) → **New repository**
4. Name it: `atlantean-gardens`
5. Make it **Public** (required for free GitHub Pages)
6. Don't add README, .gitignore, or license (we have our own files)
7. Click **Create repository**

### STEP 4: Upload Your Files to GitHub

**Option A: Via GitHub Website (Easiest)**
1. On your new repository page, click **uploading an existing file**
2. Drag ALL your files and folders into the upload area
3. Scroll down and click **Commit changes**

**Option B: Via GitHub Desktop (Recommended if you'll update often)**
1. Download GitHub Desktop: https://desktop.github.com/
2. Sign in with your GitHub account
3. Clone your `atlantean-gardens` repository
4. Copy all your website files into that folder
5. In GitHub Desktop, write a commit message: "Initial Atlantean Gardens site"
6. Click **Commit to main**
7. Click **Push origin**

### STEP 5: Enable GitHub Pages
1. Go to your repository on github.com
2. Click **Settings** (top menu)
3. Click **Pages** (left sidebar)
4. Under "Source": Select **main** branch
5. Click **Save**
6. Wait 1-2 minutes
7. Your site will be live at: `https://[your-username].github.io/atlantean-gardens/`

---

## ⚙️ IMPORTANT CUSTOMIZATIONS

### 1. CHANGE THE PASSWORD (Members Portal)
Open `members.js` and change this line:
```javascript
const MEMBERS_PASSWORD = "atlantis2026"; // CHANGE THIS!
```
Pick a secure password and replace `"atlantis2026"` with your new password.

### 2. ADD YOUR SIGNAL NUMBER
Search and replace `[Your Signal Number]` in these files:
- `index.html`
- `members.html`
- `shop.html`
- `about.html`

### 3. SET UP TYPEFORM (For Orders)
1. Go to: https://www.typeform.com (free account)
2. Create a new form with these fields:
   - Name
   - Signal/Phone Number
   - Delivery Address
   - Product Selection (dropdown)
   - Quantities
   - Preferred Delivery Day/Time
   - Special Notes
3. Get your Typeform embed link
4. In `members.html`, find this line:
   ```html
   <iframe id="typeform-embed" src="https://form.typeform.com/to/YOUR_FORM_ID"
   ```
5. Replace `YOUR_FORM_ID` with your actual Typeform link

---

## 🎨 HOW TO CUSTOMIZE

### Change Colors
Edit `styles.css` at the top where it says:
```css
:root {
    --primary-teal: #2a7d7d;
    --light-teal: #5fa8a8;
    --moss-green: #5a7a5a;
    ...
}
```

### Add New Strains
Edit `members.html` and copy/paste the strain card template:
```html
<div class="strain-card">
    <img src="images/your-strain.png" alt="Strain Name">
    <h4>Strain Name</h4>
    <p class="strain-type">Indica/Sativa/Hybrid</p>
    <p class="strain-description">Your poetic description...</p>
    <p class="strain-mood">🌸 Mood keywords</p>
</div>
```

### Update Pricing
Edit the pricing section in `members.html`

---

## 🔐 SECURITY NOTES

**The password protection is CLIENT-SIDE** which means:
- It's fine for keeping casual browsers out
- It's NOT secure against determined hackers
- Anyone can view the source code and see the password
- This is suitable for your use case (trusted community)

**For stronger security**, you'd need:
- Server-side authentication
- Database for user accounts
- Paid hosting (not GitHub Pages)

For now, this works perfectly for your business model!

---

## 📱 TESTING YOUR SITE

Before going live, test:
1. Does the password work in members portal?
2. Do all navigation links work?
3. Does it look good on your phone? (Open in mobile browser)
4. Are all images showing?
5. Does the menu open on mobile?

---

## 🌐 CUSTOM DOMAIN (Optional - Future)

Once you want a real domain like `atlanteangardens.com`:

1. Buy domain from Namecheap, Google Domains, etc. (~$12/year)
2. In your GitHub repo Settings → Pages
3. Add your custom domain
4. Follow GitHub's DNS setup instructions
5. Wait 24 hours for DNS to propagate

---

## 🆘 TROUBLESHOOTING

**Site not loading?**
- Wait 2-3 minutes after enabling Pages
- Check repository is Public
- Check files are in root folder (not nested in extra folder)

**Images not showing?**
- Make sure images folder uploaded correctly
- Check image file names match exactly in HTML

**Password not working?**
- Check you saved `members.js` with your new password
- Clear browser cache and try again

**Mobile menu not opening?**
- Make sure `script.js` uploaded correctly
- Check browser console for errors (F12 → Console tab)

---

## 📞 NEXT STEPS

1. ✅ Upload files to GitHub
2. ✅ Enable GitHub Pages
3. ✅ Change password in `members.js`
4. ✅ Add your Signal number
5. ✅ Set up Typeform
6. ✅ Test everything
7. ✅ Share link with customers
8. 🌿 Watch Atlantis rise!

---

## 💚 REMEMBER

This site is yours to grow. The code is clean, commented, and easy to modify. 
As you learn more, you can add features, change designs, expand the garden.

The most important thing: it captures the essence of Atlantean Gardens. 
Soft. Beautiful. Intentional. Kind.

**Atlantis is rising. The gardens are blooming. Welcome home.** 🌊✨

---

*Need help? You can always come back and ask Claude to modify or add features!*
